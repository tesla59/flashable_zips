#!/sbin/sh
rm -rf /system_root/system/product/app/Calender
rm -rf /system_root/system/product/priv-app/Dialer
rm -rf /system_root/system/product/app/messaging
rm -rf /system_root/system/product/app/DeskClock
rm -rf /system_root/system/product/priv-app/Contacts
